CREATE DATABASE IF NOT EXISTS telefon_db;
USE telefon_db;

CREATE TABLE IF NOT EXISTS kayitlar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ad VARCHAR(100) NOT NULL,
    eposta VARCHAR(150) NOT NULL,
    telefon CHAR(6) NOT NULL,
    olusturulma_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY benzersiz_telefon (telefon)
);