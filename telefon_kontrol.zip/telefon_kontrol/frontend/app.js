
document.addEventListener('DOMContentLoaded', () => {
    kayitlariYukle();
    
    const form = document.getElementById('registerForm');
    if (form) {
        form.addEventListener('submit', formGonder);
    }
});

document.addEventListener('click', async function(e) {
   
    const silButonu = e.target.closest('.delete-btn');
    
    if (silButonu) {
       
        const id = silButonu.getAttribute('data-id');
        if (id) {
            await kayitSilIslemi(id);
        }
    }
});



async function formGonder(olay) {
    olay.preventDefault();
    
    const adDegeri = document.getElementById('name').value;
    const emailDegeri = document.getElementById('email').value;
    const telDegeri = document.getElementById('phone').value;
    
    const mesajKutusu = document.getElementById('messageBox');
    const buton = document.getElementById('submitBtn');

    buton.disabled = true;
    buton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> İşleniyor...'; 
    mesajKutusu.className = 'hidden';

    try {
        const cevap = await fetch('http://localhost:5001/api/kayit/olustur', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                ad: adDegeri, 
                eposta: emailDegeri, 
                telefon: telDegeri 
            })
        });

        const veri = await cevap.json();
        mesajKutusu.classList.remove('hidden');
        
        if (veri.durum === 'kabul_edildi') {
            mesajKutusu.innerText = veri.mesaj;
            mesajKutusu.className = 'success';
            document.getElementById('registerForm').reset();
            kayitlariYukle(); 
        } else {
            mesajKutusu.innerText = veri.mesaj || veri.hata;
            mesajKutusu.className = 'error';
            if(veri.durum === 'reddedildi') {
                document.getElementById('phone').value = '';
            }
        }

    } catch (hata) {
        console.error('Bağlantı Hatası:', hata);
        mesajKutusu.innerText = "Sunucu ile iletişim kurulamadı.";
        mesajKutusu.className = 'error';
    } finally {
        buton.disabled = false;
        buton.innerHTML = '<i class="fas fa-check-circle"></i> Kaydı Tamamla';
    }
}

async function sayimiKontrolEt() {
    try {
        const cevap = await fetch('http://localhost:5001/api/telefon/say');
        const veri = await cevap.json();
        
        document.getElementById('countResult').innerText = 
            `Matematiksel analize göre toplam ${veri.toplam_gecerli_numara} adet olası numara bulundu.`;
    } catch (hata) {
        document.getElementById('countResult').innerText = "Hesaplama servisine ulaşılamadı.";
    }
}

async function kayitlariYukle() {
    try {
        const cevap = await fetch('http://localhost:5001/api/kayitlar/getir');
        if (!cevap.ok) return;

        const liste = await cevap.json();
        const tabloGovdesi = document.querySelector('#usersTable tbody');
        if (!tabloGovdesi) return;
        tabloGovdesi.innerHTML = '';

        liste.forEach(kisi => {
            const tarih = new Date(kisi.olusturulma_tarihi).toLocaleString('tr-TR');
            
            const satir = `
                <tr style="border-bottom: 1px solid #eee;">
                    <td style="padding: 8px;">${kisi.ad}</td>
                    <td style="padding: 8px;">${kisi.telefon}</td>
                    <td style="padding: 8px; font-size: 0.9em; color: #666;">${tarih}</td>
                    <td style="padding: 8px; text-align: center;">
                        <button class="delete-btn" data-id="${kisi.id}">
                            <i class="fas fa-trash"></i> Sil
                        </button>
                    </td>
                </tr>
            `;
            tabloGovdesi.innerHTML += satir;
        });
    } catch (hata) {
        console.error('Liste çekilemedi:', hata);
    }
}


async function kayitSilIslemi(id) {
    if (!confirm('Bu kaydı silmek istediğinize emin misiniz?')) {
        return;
    }

    try {
        const cevap = await fetch(`http://localhost:5001/api/kayit/sil/${id}`, {
            method: 'DELETE'
        });

        const veri = await cevap.json();

        if (cevap.ok) {
            alert(veri.mesaj || "Kayıt başarıyla silindi.");
            kayitlariYukle(); 
        } else {
            alert("Hata: " + (veri.hata || veri.mesaj));
        }

    } catch (hata) {
        console.error('Silme işlemi hatası:', hata);
        alert("Sunucuya ulaşılamadı, silme işlemi başarısız.");
    }
}