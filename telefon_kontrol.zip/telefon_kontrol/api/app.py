from flask import Flask, request, jsonify
from flask_mysqldb import MySQL
from flask_cors import CORS
import os

uygulama = Flask(__name__)
CORS(uygulama) 

uygulama.config['MYSQL_HOST'] = os.environ.get('VT_SUNUCU', 'veritabani')
uygulama.config['MYSQL_USER'] = os.environ.get('VT_KULLANICI', 'root')
uygulama.config['MYSQL_PASSWORD'] = os.environ.get('VT_SIFRE', 'root')
uygulama.config['MYSQL_DB'] = os.environ.get('VT_ISMI', 'telefon_db')
uygulama.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql_baglantisi = MySQL(uygulama)



def kurallari_kontrol_et(numara_str):
   
    if not numara_str.isdigit() or len(numara_str) != 6:
        return False, {}
    
    rakamlar = [int(d) for d in numara_str]
    
    # Kural 1: En az bir tane 0'dan farklı rakam olmalı
    sifirdan_farkli_var_mi = any(d != 0 for d in rakamlar)
    
    # Kural 2: İlk 3 toplamı = Son 3 toplamı
    ilk_uc_toplam = sum(rakamlar[:3])
    son_uc_toplam = sum(rakamlar[3:])
    esit_toplam_mi = (ilk_uc_toplam == son_uc_toplam)
    
    # Kural 3: Teklerin toplamı = Çiftlerin toplamı 
    tek_haneler_toplami = rakamlar[0] + rakamlar[2] + rakamlar[4]
    cift_haneler_toplami = rakamlar[1] + rakamlar[3] + rakamlar[5]
    tek_cift_esit_mi = (tek_haneler_toplami == cift_haneler_toplami)

    kurallar = {
        "sifirdanFarkliRakamVar": sifirdan_farkli_var_mi,
        "ilkVeSonToplamiEsit": esit_toplam_mi,
        "tekVeCiftToplamiEsit": tek_cift_esit_mi
    }
    
    gecerli_mi = sifirdan_farkli_var_mi and esit_toplam_mi and tek_cift_esit_mi
    return gecerli_mi, kurallar


@uygulama.route('/api/telefon/dogrula', methods=['POST'])
def telefon_dogrula():
    veri = request.get_json()
    numara = veri.get('telefon', '') 
    
    gecerli_mi, kurallar = kurallari_kontrol_et(numara)
    
    if not kurallar: 
        return jsonify({"hata": "Telefon numarası 6 haneli sayısal bir değer olmalıdır."}), 400

    return jsonify({
        "numara": numara,
        "kurallar": kurallar,
        "gecerliMi": gecerli_mi
    })

@uygulama.route('/api/kayit/olustur', methods=['POST'])
def kullanici_kaydet():
    veri = request.get_json()
    ad = veri.get('ad')
    eposta = veri.get('eposta')
    telefon = veri.get('telefon')
    
    
    if not all([ad, eposta, telefon]):
        return jsonify({"durum": "reddedildi", "mesaj": "Eksik bilgi."}), 400
        
    gecerli_mi, kurallar = kurallari_kontrol_et(telefon)
    
    if not gecerli_mi:
        return jsonify({
            "durum": "reddedildi",
            "mesaj": "Geçersiz telefon numarası. Lütfen yeni bir numara deneyin.",
            "gecerliMi": False
        }), 422
        
    
    try:
        imlec = mysql_baglantisi.connection.cursor()
        imlec.execute(
            "INSERT INTO kayitlar (ad, eposta, telefon) VALUES (%s, %s, %s)",
            (ad, eposta, telefon)
        )
        mysql_baglantisi.connection.commit()
        yeni_id = imlec.lastrowid
        imlec.close()
        
        return jsonify({
            "durum": "kabul_edildi",
            "mesaj": "Telefon numarası geçerli, kayıt başarıyla oluşturuldu.",
            "veri": {
                "id": yeni_id,
                "ad": ad,
                "eposta": eposta,
                "telefon": telefon
            }
        }), 201
        
    except Exception as hata:
        if "Duplicate entry" in str(hata):
             return jsonify({
                "durum": "reddedildi",
                "mesaj": "Bu telefon numarası zaten kayıtlı.",
                "gecerliMi": True
            }), 409
             
        return jsonify({"hata": str(hata)}), 500

@uygulama.route('/api/telefon/say', methods=['GET'])
def gecerli_numaralari_say():
    sayac = 0
    for d1 in range(10):
        for d2 in range(10):
            for d3 in range(10):
                for d4 in range(10):
                    
                    d5 = d2 
                  
                    gerekli_d6 = (d1 + d3) - d4
                    
                    if 0 <= gerekli_d6 <= 9:
                        if not (d1==0 and d2==0 and d3==0 and d4==0 and d5==0 and gerekli_d6==0):
                            sayac += 1
                            
    return jsonify({
        "toplam_gecerli_numara": sayac,
        "algoritma_notu": "Matematiksel kurallara göre optimize edilmiş döngü kullanıldı."
    })

@uygulama.route('/api/kayitlar/getir', methods=['GET'])
def kayitlari_getir():
    try:
        imlec = mysql_baglantisi.connection.cursor()
        
        imlec.execute("SELECT id, ad, eposta, telefon, olusturulma_tarihi FROM kayitlar ORDER BY olusturulma_tarihi DESC LIMIT 10")
        kullanicilar = imlec.fetchall()
        imlec.close()
        return jsonify(kullanicilar)
    except Exception as hata:
        return jsonify({"hata": str(hata)}), 500


@uygulama.route('/api/kayit/sil/<int:id>', methods=['DELETE'])
def kayit_sil(id):
    try:
        imlec = mysql_baglantisi.connection.cursor()
        imlec.execute("DELETE FROM kayitlar WHERE id = %s", (id,))
        mysql_baglantisi.connection.commit()
        imlec.close()
        return jsonify({"durum": "kabul_edildi", "mesaj": "Kayıt başarıyla silindi."}), 200
    except Exception as e:
        return jsonify({"hata": str(e)}), 500

if __name__ == '__main__':
    uygulama.run(host='0.0.0.0', port=5000, debug=True)